# 🐦 HabitBird — Gamified Habit Tracker

> A Finch-inspired habit tracker where your habits grow a virtual bird.  
> Built with **React Native (Expo)** + **Firebase** (Auth + Firestore + Realtime Sync).

---

## 📱 Screens

| Screen | Description |
|--------|-------------|
| **Auth** | Login / Register with email & password |
| **Home** | Bird stage, XP bar, habit list, stats, milestones |
| **Journal** | Real-time log of every habit completed or missed |
| **Profile** | Achievements, rename bird, account settings |

---

## 🚀 Setup & Run

### 1. Prerequisites
- Node.js 18+
- Expo CLI: `npm install -g expo-cli`
- Expo Go app on your phone (iOS / Android)

### 2. Install dependencies
```bash
npm install
```

### 3. Set up Firebase

1. Go to [Firebase Console](https://console.firebase.google.com)
2. Create a new project
3. Add a **Web App** to your project
4. Copy your config values
5. Open `firebase/config.js` and replace the placeholder values:

```js
const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT_ID.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  ...
};
```

6. Enable **Email/Password Authentication**:  
   Firebase Console → Authentication → Sign-in method → Email/Password → Enable

7. Enable **Firestore Database**:  
   Firebase Console → Firestore Database → Create Database → Start in test mode

8. Paste Firestore security rules from `firestore.rules` into:  
   Firebase Console → Firestore → Rules → Publish

### 4. Run the app
```bash
npx expo start
```
- Scan the QR code with Expo Go on your phone, OR
- Press `w` to open in browser, `a` for Android emulator, `i` for iOS simulator

---

## 🛠️ Tech Stack

| Technology | Usage |
|-----------|-------|
| React Native | Cross-platform mobile UI |
| Expo | Build tooling, LinearGradient, icons |
| Firebase Auth | Email/password authentication |
| Firestore | Cloud database with realtime sync |
| React Navigation | Tab + stack navigation |
| React Context API | Global auth state |
| Animated API | Bird bounce, XP animations |

---

## 🗂️ Project Structure

```
habitbird/
├── App.js                    # Root — navigation + auth gating
├── firebase/
│   ├── config.js             # Firebase initialization
│   └── services.js           # Auth + Firestore + realtime functions
├── context/
│   └── AuthContext.js        # Global auth state
├── constants/
│   └── gameData.js           # Levels, milestones, achievements, helpers
├── screens/
│   ├── AuthScreen.js         # Login / Register
│   ├── HomeScreen.js         # Main bird + habits screen
│   ├── JournalScreen.js      # Activity log
│   └── ProfileScreen.js      # Achievements + settings
├── firestore.rules           # Firestore security rules
└── package.json
```

---

## 🎮 Game Mechanics

- **Complete habit** → +XP, +5 HP, habit streak++
- **Miss habit** → -10 HP, streak resets
- **New day** → missed habits deal bulk damage, streak updates
- **Level up** → bird evolves through 8 stages with different emojis
- **Milestones** → unlock at key progress points
- **Achievements** → hidden rewards for power users

---

## 📋 Portfolio Description

**Languages & Technologies:** React Native, JavaScript (ES6+), Firebase (Auth + Firestore + Realtime Listeners), Expo, React Navigation, React Context API, CSS-in-JS (StyleSheet)

**Technical Highlights:**
- Firebase Authentication with email/password login and secure session persistence
- Firestore real-time listeners (`onSnapshot`) sync habits, profile, and journal across devices instantly
- Firestore security rules ensure users can only access their own data
- Game loop built from scratch: XP thresholds, level gating, HP damage/heal system, streak tracking
- Day-change detection logic applies missed-habit penalties automatically on next app open
- React Context API manages global auth state with clean separation from UI components
- Cross-platform — runs on iOS, Android, and Web from a single codebase via Expo
